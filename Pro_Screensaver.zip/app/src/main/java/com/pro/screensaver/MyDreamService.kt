package com.pro.screensaver
import android.content.*
import android.graphics.Color
import android.os.*
import android.service.dreams.DreamService
import android.view.View
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*

class MyDreamService : DreamService() {
    private lateinit var movingBox: View
    private val handler = Handler(Looper.getMainLooper())
    
    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        isFullscreen = true
        isInteractive = false
        setContentView(R.layout.screensaver_layout)
        movingBox = findViewById(R.id.moving_box)
        updateUI()
    }

    private fun updateUI() {
        val prefs = getSharedPreferences("prefs", MODE_PRIVATE)
        val clock = findViewById<TextClock>(R.id.clock)
        val owner = findViewById<TextView>(R.id.owner_msg)
        val date = findViewById<TextView>(R.id.date_text)

        val color = Color.parseColor(prefs.getString("color", "#FFFFFF"))
        clock.setTextColor(color)
        clock.format12Hour = if (prefs.getBoolean("seconds", true)) "hh:mm:ss a" else "hh:mm a"
        owner.text = prefs.getString("msg", "Locked Device")
        date.text = SimpleDateFormat("EEEE, MMM d", Locale.getDefault()).format(Date())
    }

    override fun onDreamingStarted() {
        super.onDreamingStarted()
        startAnimation()
        registerReceiver(batteryReceiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
    }

    private fun startAnimation() {
        handler.postDelayed(object : Runnable {
            override fun run() {
                val parent = movingBox.parent as View
                movingBox.animate()
                    .x(Random().nextInt(Math.max(1, parent.width - movingBox.width)).toFloat())
                    .y(Random().nextInt(Math.max(1, parent.height - movingBox.height)).toFloat())
                    .setDuration(5000).start()
                handler.postDelayed(this, 15000)
            }
        }, 1000)
    }

    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            val level = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) ?: 0
            findViewById<TextView>(R.id.battery_text).text = "Battery: $level%"
        }
    }

    override fun onDreamingStopped() {
        super.onDreamingStopped()
        handler.removeCallbacksAndMessages(null)
        try { unregisterReceiver(batteryReceiver) } catch(e: Exception) {}
    }
}