package com.pro.screensaver
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class SettingsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)
        val prefs = getSharedPreferences("prefs", MODE_PRIVATE)

        findViewById<Button>(R.id.btn_save).setOnClickListener {
            prefs.edit().apply {
                putString("msg", findViewById<EditText>(R.id.edit_msg).text.toString())
                putString("color", findViewById<EditText>(R.id.edit_color).text.toString())
                putBoolean("seconds", findViewById<CheckBox>(R.id.check_seconds).isChecked)
                apply()
            }
            Toast.makeText(this, "Saved!", Toast.LENGTH_SHORT).show()
            finish()
        }
    }
}